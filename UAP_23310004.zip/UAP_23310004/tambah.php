<?php
session_start();
if (!isset($_SESSION['login'])){
    header("Location:login.php");
    exit;
}
require 'fungsi.php';
// koneksi
$koneksi = mysqli_connect("localhost","root","","perpustakaan");

// cek tombool submit
if(isset($_POST["submit"])){
    //cek data berhasil disimpan/tidak
    if(tambah($_POST) > 0){
        echo "<script>
                alert ('data berhasil ditambahkan');
                document.location.href = 'indeks.php';
                </script>";
    } else {
        echo "<script>
        alert ('data gagal ditambahkan');
        document.location.href = 'indeks.php';
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Data Mahasiswa</title>
  <style>
    body {
      font-family: Arial, sans-serif;
    }
    form {
      width: 500px;
      margin: 0 auto;
      padding: 20px;
      border: 1px solid #ccc;
    }
    label {
      display: block;
      margin-bottom: 5px;
    }
    input[type="text"],
    input[type="number"],
    textarea,
    select {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      box-sizing: border-box;
    }
    button {
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h1>Tambah Data Mahasiswa</h1>

  <form action="" method="post">
  <label for="nim">Nim:</label>
  <input type="text" id="nim" name="nim" required>

    <label for="nama">Nama:</label>
    <input type="text" id="nama" name="nama" required>

    <label for="jenkel">Jenis Kelamin:</label>
    <div>
      <input type="radio" id="lk" name="jenkel" value="L" required>
      <label for="lk">Laki-laki</label>

      <input type="radio" id="pr" name="jenkel" value="P">
      <label for="pr">Perempuan</label>
    </div>

    <label for="agama">Agama:</label>
    <select id="agama" name="agama" required>
      <option value="">Pilih Agama</option>
      <option value="Islam">Islam</option>
      <option value="Kristen">Kristen</option>
      <option value="Katolik">Katolik</option>
      <option value="Hindu">Hindu</option>
      <option value="Budha">Budha</option>
      <option value="Konghucu">Konghucu</option>
    </select>

    <label for="alamat">Alamat:</label>
    <textarea id="alamat" name="alamat" rows="5" required></textarea>

    <label for="telepon">Telepon:</label>
    <input type="text" id="telepon" name="telepon" required>
            <button type="submit" name="submit">Simpan Data</button>
        </ul>
    </form>
    <h3><a href="indeks.php">Kembali</h3>
</body>
</html> 