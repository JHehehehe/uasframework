<?php

$koneksi = mysqli_connect("localhost","root","","perpustakaan");
function query($query){
    global $koneksi;
    $hasil =mysqli_query($koneksi, $query);
    $data = [];
    while($data_baris =mysqli_fetch_assoc($hasil)){
        $data[] = $data_baris;
    }
    return $data;
}
 
function tambah($data){
    global $koneksi;
    //mengambil data pada form di tiap elemennya
    $nim = htmlspecialchars ($data["nim"]);
    $nama = htmlspecialchars ($data["nama"]);
    $jenkel = htmlspecialchars ($data["jenkel"]);
    $agama = htmlspecialchars ($data["agama"]);
    $alamat = htmlspecialchars ($data["alamat"]);
    $telepon = htmlspecialchars ($data["telepon"]);


    // query tambah data
    $query = "INSERT INTO anggota (nim, nama,jenkel,agama,alamat,telepon) VALUES
            ('$nim', '$nama','$jenkel','$agama','$alamat','$telepon')";

    mysqli_query($koneksi,$query);
    return mysqli_affected_rows($koneksi);
}


function hapus($id) {
    global $koneksi;
    mysqli_query($koneksi, "DELETE FROM anggota WHERE id = $id");
    return mysqli_affected_rows($koneksi);
}

function ubah($data) {
    // mengambil data pada form di tiap elemennya
    global $koneksi;
    $id=$data["id"];
    $nim = htmlspecialchars ($data["nim"]);
    $nama = htmlspecialchars ($data["nama"]);
    $jenkel = htmlspecialchars ($data["jenkel"]);
    $agama = htmlspecialchars ($data["agama"]);
    $alamat = htmlspecialchars ($data["alamat"]);
    $telepon = htmlspecialchars ($data["telepon"]);

    
    // query ubah data
    $query = "UPDATE anggota SET
            nim ='$nim, 'nama='$nama', jenkel='$jenkel', agama='$agama', alamat='$alamat', telepon='$telepon'
            WHERE ='$id'";

    mysqli_query($koneksi,$query);
    return mysqli_affected_rows($koneksi);
}

function cari($keyword){
    $query = "SELECT * FROM anggota
    WHERE nama LIKE '%$keyword%' OR
    stok LIKE '%$keyword%' OR
    harga LIKE '%$keyword%'";
    return query($query);
}

function registrasi($data){
    global $koneksi;
    $username = strtolower(stripslashes($data["username"]));
    $password = mysqli_real_escape_string($koneksi, $data["password"]);
    $password2 = mysqli_real_escape_string($koneksi, $data["password2"]);


    //cek konfirmasi password
    if($password!==$password2){
        echo "<script>
        alert('konfirmasi password tidak seusai')
        </script>";
    return false;
    }

    //cek username yg sama
    $result = mysqli_query($koneksi,"SELECT username FROM user WHERE username = '$username'");
    if(mysqli_fetch_assoc($result)){
        echo "<script>
        alert('username sudah ada')
        </script>";
    return false;

    }
   
    //enkripsi password
    $password = password_hash($password,PASSWORD_DEFAULT);
    //$password = md5($password);
    //var_dump($password); die;

    mysqli_query($koneksi,"INSERT INTO user VALUES('','$username','$password') ");
    return mysqli_affected_rows($koneksi);


}

?>