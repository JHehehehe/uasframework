<?php
    session_start();
    if (!isset($_SESSION["login"])){
        header("Location:login.php");
        exit;
    }
    
require 'fungsi.php';

//pagination
$perhalaman = 2;
$totaljumlah = count(query("SELECT * FROM anggota"));
$jumlahhalaman = ceil($totaljumlah / $perhalaman);
$halamanaktif = (isset($_GET['halaman'])) ? $_GET["halaman"] : 1;
$awaldata = ($perhalaman * $halamanaktif) - $perhalaman;
$barang = query("SELECT * FROM anggota LIMIT $awaldata, $perhalaman");

// jika tombol cari di tekan
if(isset ($_POST["cari"])){
    $barang= cari($_POST["keyword"]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Admin</title>
    <style>
        @media print{
            .logout, .tambah , .form-cari, .aksi{
                display: none;
            }
        }

        table {
            width: 800px;
            height: 200px;
        }
        td{
            text-align: center;
        }
    </style>
</head>


<body>
<a href="logout.php" class="logout">Logout</a>

    <h1>Daftar Mahasiswa</h1>
    <a href="tambah.php" class="tambah">Tambah Data Mahasiswa</a>
    <!-- <a href="login.php">Login</a> -->
    <br><br>

<form action="" method="POST" class="form-cari">
    <input type="text" name="keyword" size="40" autofocus placeholder="masukan kata yang dicari" autocomplete="off">
    <button type="submit" name="cari"> Cari </button>
</form>

<!-- navigasi-->
<?php if($halamanaktif > 1): ?>
    <a href="?halaman=<?= $halamanaktif - 1; ?>">&laquo;</a>
<?php endif; ?>

<?php for($i=1; $i <= $jumlahhalaman; $i++): ?>
    <?php if( $i==$halamanaktif) : ?>
        <a href="?halaman<?= $i; ?> "style="font-weight: bold; color: green;"><?= $i; ?></a>
    <?php else: ?>
        <a href="?halaman=<?= $i ?>"><?= $i ?></a>
    <?php endif; ?>
<?php endfor ?>

<?php if($halamanaktif < $jumlahhalaman): ?>
    <a href="?halaman=<?= $halamanaktif + 1; ?>">&raquo;</a>
<?php endif; ?>
<br>
    <table border="1" cellpading="10" cellspacing="0">
        <tr>
        <th>Nim</th>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>Agama</th>
            <th>Alamat</th>
            <th>Telepon</th>
            <th class="aksi">Aksi</th>
        </tr>
        <?php $no_urut = 1; ?>
        <?php foreach ($barang as $data_baris) :?>

        <tr>
        <td><?= $data_baris["nim"];?></td>
            <td><?= $data_baris["nama"];?></td>
            <td><?= $data_baris["jenkel"];?></td>
            <td><?= $data_baris["agama"];?></td>
            <td><?= $data_baris["alamat"];?></td>
            <td><?= $data_baris["telepon"];?></td>

            <td>
                <a href="update.php?id=<?= $data_baris["id"];?>">update</a>
                <a href="hapus.php?id=<?= $data_baris["id"];?>" onclick = "return confirm('yakin data akan dihapus?');">hapus</a>
            </td>
        </tr>
        <?php $no_urut++; ?>
    <?php endforeach;?>
    </table>
</body>
</html>