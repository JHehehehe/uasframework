<?php
session_start();
if (!isset($_SESSION['login'])){
    header("Location:login.php");
    exit;
}
require 'fungsi.php';
// koneksi
$koneksi = mysqli_connect("localhost","root","","perpustakaan");

// ambil data dari url
$id = $_GET["id"];

// query data barang berdasarkan id
$barang=query("SELECT * FROM barang WHERE id=$id")[0];

// cek tombool submit
if(isset($_POST["submit"])){
    //cek data berhasil diubah/tidak
    if(ubah($_POST) > 0){
        echo "<script>
                alert ('data berhasil diupdate');
                document.location.href = 'indeks.php';
                </script>";
    } else {
        echo "<script>
        alert ('data gagal diupdate');
        document.location.href = 'indeks.php';
        </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
</head>
<body>
    <form action="" method="post" enctype="multipart/form-data">
    <h1>Update Data Barang</h1>
        <input type="hidden" name="id" value="<?= $barang["id"] ?>">
        <input type="hidden" name="fotoLama" value="<?= $barang["foto"] ?>">
        <ul>
            <li>
                <label for="nama">Nama Mahasiswa  : </label>
                <input type="text" name="nama" id="nama" required value="<?= $barang["nama"]?>">
            </li>
            <li>
                <label for="jenkel">Jenis Kelamin  : </label>
                <input type="text" name="jenkel" id="jenkel" required value="<?= $barang["jenkel"]?>">
            </li>
            <li>
                <label for="agama">agama    : </label>
                <input type="text" name="agama" id="agama" required value="<?= $barang["agama"]?>">
            </li>
            <li>
                <label for="alamat">alamat    : </label>
                <input type="text" name="alamat" id="alamat" required value="<?= $barang["alamat"]?>">
            </li>
            <li>
                <label for="telepo">telepon   : </label>
                <input type="text" name="telepon" id="telepon" required value="<?= $barang["telepon"]?>">
            </li>
        
           
            <button type="submit" name="submit">Simpan Data</button>
        </ul>
    </form>
    <h3><a href="indeks.php">Kembali</h3>
</body>
</html> 