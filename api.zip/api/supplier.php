<?php
// Konfigurasi CORS agar API dapat diakses dari domain lain (seperti React frontend)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");

// Aktifkan penampilan error untuk debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Koneksi ke database MySQL
$koneksi = mysqli_connect("localhost", "root", "", "toko");

// Ambil parameter 'action' dari URL dan data JSON dari body request
$action = $_GET['action'] ?? '';
$data = json_decode(file_get_contents("php://input"), true);

// Fungsi validasi input supplier
function validasi($data) {
    if (empty($data['nama']) || strlen(trim($data['nama'])) < 3)
        return "Nama harus lebih dari 3 karakter.";
    if (empty($data['kontak']))
        return "Kontak harus diisi.";
    return true;
}

// Logika berdasarkan nilai 'action'
switch ($action) {

    // Ambil detail 1 data supplier berdasarkan ID
    case 'detail':
        if (!isset($_GET['id'])) {
            echo json_encode(['error' => 'ID tidak ditemukan.']);
            exit;
        }
        $id = (int) $_GET['id'];
        $query = mysqli_query($koneksi, "SELECT * FROM supplier WHERE id = $id");
        $detail = mysqli_fetch_assoc($query);
        echo json_encode($detail ?: ['error' => 'Data tidak ditemukan.']);
        break;

    // Ambil seluruh data supplier
    case 'read':
        $hasil = mysqli_query($koneksi, "SELECT * FROM supplier ORDER BY id ASC");
        $data = [];
        while($row = mysqli_fetch_assoc($hasil)){
            $data[] = $row;
        }
        echo json_encode($data);
        break;

    // Tambahkan supplier baru ke database
    case 'create':
        $cek = validasi($data);
        if ($cek !== true) {
            echo json_encode(['error' => $cek]);
            exit;
        }
        $nama = htmlspecialchars($data['nama']);
        $kontak = htmlspecialchars($data['kontak']);

        $query = "INSERT INTO supplier (nama, kontak) VALUES ('$nama', '$kontak')";
        $res = mysqli_query($koneksi, $query);
        if (!$res) {
            echo json_encode(['error' => mysqli_error($koneksi)]);
            exit;
        }
        echo json_encode(['status' => 'created']);
        break;

    // Update data supplier berdasarkan ID
    case 'update':
        $cek = validasi($data);
        if ($cek !== true || !isset($data['id'])) {
            echo json_encode(['error' => $cek ?: "ID tidak ditemukan."]);
            exit;
        }
        $id = (int)$data['id'];
        $nama = htmlspecialchars($data['nama']);
        $kontak = htmlspecialchars($data['kontak']);

        $query = "UPDATE supplier SET nama='$nama', kontak='$kontak' WHERE id=$id";
        $res = mysqli_query($koneksi, $query);
        if (!$res) {
            echo json_encode(['error' => mysqli_error($koneksi)]);
            exit;
        }
        echo json_encode(['status' => 'updated']);
        break;

    // Hapus data supplier berdasarkan ID
    case 'delete':
        if (!isset($data['id'])) {
            echo json_encode(['error' => 'ID tidak dikirim.']);
            exit;
        }
        $id = (int)$data['id'];
        $res = mysqli_query($koneksi, "DELETE FROM supplier WHERE id = $id");
        if (!$res) {
            echo json_encode(['error' => mysqli_error($koneksi)]);
            exit;
        }

        // Jika tabel kosong setelah penghapusan, reset nilai AUTO_INCREMENT ke 1
        $cek = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM supplier");
        $row = mysqli_fetch_assoc($cek);
        if ($row['total'] == 0) {
            mysqli_query($koneksi, "ALTER TABLE supplier AUTO_INCREMENT = 1");
        }

        echo json_encode(['status' => 'deleted']);
        break;

    // Tindakan default jika action tidak dikenali
    default:
        echo json_encode(['error' => 'Aksi tidak dikenali.']);
}
?>
