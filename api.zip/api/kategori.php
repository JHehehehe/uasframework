<?php
// Mengatur header agar API bisa diakses dari frontend (CORS)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");

// Menampilkan error saat pengembangan
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "toko");

// Ambil action dari URL dan data dari body request
$action = $_GET['action'] ?? '';
$data = json_decode(file_get_contents("php://input"), true);

// Fungsi validasi input nama dan deskripsi
function validasi($data) {
    if (empty($data['nama']) || strlen(trim($data['nama'])) < 3) {
        return "Nama harus lebih dari 3 karakter.";
    }
    if (!isset($data['deskripsi']) || strlen(trim($data['deskripsi'])) < 5) {
        return "Deskripsi harus lebih dari 5 karakter.";
    }
    return true;
}

switch ($action) {
    // Ambil 1 kategori berdasarkan ID
    case 'detail':
        if (!isset($_GET['id'])) {
            echo json_encode(['error' => 'ID tidak ditemukan.']);
            exit;
        }
        $id = (int) $_GET['id'];
        $query = mysqli_query($koneksi, "SELECT * FROM kategori WHERE id = $id");
        $detail = mysqli_fetch_assoc($query);
        echo json_encode($detail);
        break;

    // Ambil semua kategori (untuk dropdown)
    case 'read':
        $hasil = mysqli_query($koneksi, "SELECT id, nama FROM kategori ORDER BY nama ASC");
        $data = [];
        while ($row = mysqli_fetch_assoc($hasil)) {
            $data[] = $row;
        }
        echo json_encode($data);
        break;

    // Tambah kategori baru
    case 'create':
        $cek = validasi($data);
        if ($cek !== true) {
            echo json_encode(['error' => $cek]);
            exit;
        }
        $nama = htmlspecialchars($data['nama']);
        $deskripsi = htmlspecialchars($data['deskripsi']);
        $query = "INSERT INTO kategori (nama, deskripsi) VALUES ('$nama', '$deskripsi')";
        $res = mysqli_query($koneksi, $query);
        if (!$res) {
            echo json_encode(['error' => mysqli_error($koneksi)]);
            exit;
        }
        echo json_encode(['status' => 'created']);
        break;

    // Update kategori
    case 'update':
        $cek = validasi($data);
        if ($cek !== true || !isset($data['id'])) {
            echo json_encode(['error' => $cek ?: "ID tidak ditemukan."]);
            exit;
        }
        $id = (int) $data['id'];
        $nama = htmlspecialchars($data['nama']);
        $deskripsi = htmlspecialchars($data['deskripsi']);
        $query = "UPDATE kategori SET nama='$nama', deskripsi='$deskripsi' WHERE id=$id";
        $res = mysqli_query($koneksi, $query);
        if (!$res) {
            echo json_encode(['error' => mysqli_error($koneksi)]);
            exit;
        }
        echo json_encode(['status' => 'updated']);
        break;

    // Hapus kategori
    case 'delete':
        if (!isset($data['id'])) {
            echo json_encode(['error' => 'ID tidak dikirim.']);
            exit;
        }
        $id = (int) $data['id'];
        $res = mysqli_query($koneksi, "DELETE FROM kategori WHERE id = $id");
        if (!$res) {
            echo json_encode(['error' => mysqli_error($koneksi)]);
            exit;
        }

        // Reset auto_increment jika kosong
        $cek = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM kategori");
        $row = mysqli_fetch_assoc($cek);
        if ($row['total'] == 0) {
            mysqli_query($koneksi, "ALTER TABLE kategori AUTO_INCREMENT = 1");
        }

        echo json_encode(['status' => 'deleted']);
        break;

    // Jika aksi tidak dikenal
    default:
        echo json_encode(['error' => 'Aksi tidak dikenali.']);
}
?>
