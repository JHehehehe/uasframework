<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");

ini_set('display_errors', 1);
error_reporting(E_ALL);

$koneksi = mysqli_connect("localhost", "root", "", "toko");
$action = $_GET['action'] ?? '';

function simpanGambar($file) {
    $targetDir = dirname(__FILE__) . "/../uploads/";
    if (!is_dir($targetDir)) mkdir($targetDir, 0777, true); // pastikan bisa buat folder
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = time() . '_' . uniqid() . '.' . $ext;
    $targetPath = $targetDir . $filename;
    if (move_uploaded_file($file["tmp_name"], $targetPath)) {
        return $filename;
    }
    return '';
}


function validasi($data) {
    if (empty($data['nama']) || strlen(trim($data['nama'])) < 3)
        return "Nama harus lebih dari 3 karakter.";
    if (!isset($data['nominal']) || !is_numeric($data['nominal']))
        return "Nominal harus angka.";
    if (empty($data['stok']))
        return "Stok harus diisi.";
    if (empty($data['kategori_id']))
        return "Kategori harus dipilih.";
    return true;
}

switch ($action) {
    case 'reset_id':
        mysqli_query($koneksi, "ALTER TABLE produk AUTO_INCREMENT = 1");
        echo json_encode(['status' => 'reset']);
        break;

    case 'detail':
    $id = (int)$_GET['id'];
    $result = mysqli_query($koneksi, "
        SELECT p.*, k.nama AS kategori_nama
        FROM produk p
        LEFT JOIN kategori k ON p.kategori_id = k.id
        WHERE p.id = $id
    ");
    $data = mysqli_fetch_assoc($result);

    // Gambar URL diperbaiki agar dapat diakses langsung
    if ($data && !empty($data['gambar'])) {
        $data['gambar'] = $data['gambar']; // filename
        $data['gambar_url'] = 'http://' . $_SERVER['HTTP_HOST'] . '/uploads/' . $data['gambar'];
    } else {
        $data['gambar'] = null;
        $data['gambar_url'] = null;
    }

    echo json_encode($data);
    break;



    case 'read':
        $hasil = mysqli_query($koneksi, "
            SELECT p.*, k.nama AS kategori_nama
            FROM produk p
            LEFT JOIN kategori k ON p.kategori_id = k.id
            ORDER BY p.id ASC
        ");
        $data = [];
        while($row = mysqli_fetch_assoc($hasil)){
            $data[] = $row;
        }
        echo json_encode($data);
        break;

    case 'create':
        $nama = mysqli_real_escape_string($koneksi, $_POST['nama'] ?? '');
        $stok = mysqli_real_escape_string($koneksi, $_POST['stok'] ?? '');
        $nominal = mysqli_real_escape_string($koneksi, $_POST['nominal'] ?? '');
        $deskripsi = mysqli_real_escape_string($koneksi, $_POST['deskripsi'] ?? '');
        $kategori_id = (int)($_POST['kategori_id'] ?? 0);

        $cek = validasi($_POST);
        if ($cek !== true) {
            echo json_encode(['error' => $cek]);
            exit;
        }

        $gambar = '';
        if (!empty($_FILES['gambar']['name'])) {
            $gambar = simpanGambar($_FILES['gambar']);
        }

        $query = "INSERT INTO produk (nama, stok, nominal, deskripsi, gambar, kategori_id)
                  VALUES ('$nama', '$stok', '$nominal', '$deskripsi', '$gambar', '$kategori_id')";
        $res = mysqli_query($koneksi, $query);

        if (!$res) {
            echo json_encode(['error' => mysqli_error($koneksi)]);
            exit;
        }

        echo json_encode(['status' => 'created']);
        break;

    case 'update':
        if (!isset($_POST['id'])) {
            echo json_encode(['error' => 'ID tidak dikirim.']);
            exit;
        }

        $id = (int)$_POST['id'];
        $nama = mysqli_real_escape_string($koneksi, $_POST['nama'] ?? '');
        $stok = mysqli_real_escape_string($koneksi, $_POST['stok'] ?? '');
        $nominal = mysqli_real_escape_string($koneksi, $_POST['nominal'] ?? '');
        $deskripsi = mysqli_real_escape_string($koneksi, $_POST['deskripsi'] ?? '');
        $kategori_id = (int)($_POST['kategori_id'] ?? 0);

        $cek = validasi($_POST);
        if ($cek !== true) {
            echo json_encode(['error' => $cek]);
            exit;
        }

        $result = mysqli_query($koneksi, "SELECT gambar FROM produk WHERE id = $id");
        $lama = mysqli_fetch_assoc($result);
        $gambarLama = $lama['gambar'];

        if (!empty($_FILES['gambar']['name'])) {
            $gambarBaru = simpanGambar($_FILES['gambar']);
            if (!empty($gambarLama) && file_exists("uploads/" . $gambarLama)) {
                unlink("uploads/" . $gambarLama);
            }
        } else {
            $gambarBaru = $gambarLama;
        }

        $query = "UPDATE produk SET 
                    nama='$nama',
                    stok='$stok',
                    nominal='$nominal',
                    deskripsi='$deskripsi',
                    gambar='$gambarBaru',
                    kategori_id='$kategori_id'
                  WHERE id=$id";

        $res = mysqli_query($koneksi, $query);

        if (!$res) {
            echo json_encode(['error' => mysqli_error($koneksi)]);
            exit;
        }

        echo json_encode(['status' => 'updated']);
        break;

    case 'delete':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!isset($data['id'])) {
            echo json_encode(['error' => 'ID tidak dikirim.']);
            exit;
        }

        $id = (int)$data['id'];

        $get = mysqli_query($koneksi, "SELECT gambar FROM produk WHERE id = $id");
        $row = mysqli_fetch_assoc($get);
        if ($row && !empty($row['gambar']) && file_exists("uploads/" . $row['gambar'])) {
            unlink("uploads/" . $row['gambar']);
        }

        $res = mysqli_query($koneksi, "DELETE FROM produk WHERE id = $id");

        if (!$res) {
            echo json_encode(['error' => mysqli_error($koneksi)]);
            exit;
        }

        $cek = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk");
        $row = mysqli_fetch_assoc($cek);
        if ($row['total'] == 0) {
            mysqli_query($koneksi, "ALTER TABLE produk AUTO_INCREMENT = 1");
        }

        echo json_encode(['status' => 'deleted']);
        break;

    default:
        echo json_encode(['error' => 'Aksi tidak dikenali.']);
}
?>
