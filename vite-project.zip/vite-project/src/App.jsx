import './App.css';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import Home from './pages/Home';
import Produk from './pages/Produk';
import Supplier from './pages/Supplier';
import Kategori from './pages/Kategori';
import Pelanggan from './pages/Pelanggan';

function App() {
  return (
    <Router>
      <div className="container">
        <nav className="navbar">
          <NavLink to="/">Home</NavLink>
          <NavLink to="/produk">Produk</NavLink>
          <NavLink to="/supplier">Supplier</NavLink>
          <NavLink to="/kategori">Kategori</NavLink>
          <NavLink to="/pelanggan">Pelanggan</NavLink>
        </nav>
        <Routes>
          <Route path="/" element={<Home key="home" />} />
          <Route path="/produk" element={<Produk key="produk" />} />
          <Route path="/supplier" element={<Supplier key="supplier" />} />
          <Route path="/kategori" element={<Kategori key="kategori" />} />
          <Route path="/pelanggan" element={<Pelanggan key="pelanggan" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
