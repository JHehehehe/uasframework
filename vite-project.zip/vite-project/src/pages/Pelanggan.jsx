import { useEffect, useState } from 'react';

function Pelanggan() {
  const [data, setData] = useState([]);

  // Input states
  const [nama, setNama] = useState('');
  const [alamat, setAlamat] = useState('');
  const [jenisKelamin, setJenisKelamin] = useState('');
  const [tempatLahir, setTempatLahir] = useState('');
  const [tanggalLahir, setTanggalLahir] = useState('');

  const [id, setId] = useState(null);
  const [detail, setDetail] = useState(null);

 const loadData = () => {
  fetch('http://localhost/api/pelanggan.php?action=read')
    .then(res => res.json())
    .then(res => {
      // Urut berdasarkan ID ascending (lama ke baru)
      const sorted = res.sort((a, b) => a.id - b.id);
      setData(sorted);
    });
};


  useEffect(() => {
    loadData();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    const action = id ? 'update' : 'create';
    const payload = {
      id, nama, alamat,
      jenis_kelamin: jenisKelamin,
      tempat_lahir: tempatLahir,
      tanggal_lahir: tanggalLahir
    };

    fetch(`http://localhost/api/pelanggan.php?action=${action}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(() => {
      // Reset form
      setId(null);
      setNama('');
      setAlamat('');
      setJenisKelamin('');
      setTempatLahir('');
      setTanggalLahir('');
      setDetail(null);
      loadData();
    });
  };

  const handleEdit = (item) => {
    setId(item.id);
    setNama(item.nama);
    setAlamat(item.alamat);
    setJenisKelamin(item.jenis_kelamin || '');
    setTempatLahir(item.tempat_lahir || '');
    setTanggalLahir(item.tanggal_lahir || '');
  };

  const handleDelete = (id) => {
    if (!window.confirm("Yakin ingin menghapus data ini?")) return;
    fetch('http://localhost/api/pelanggan.php?action=delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    }).then(() => loadData());
  };

  const handleShowDetail = (id) => {
    fetch(`http://localhost/api/pelanggan.php?action=detail&id=${id}`)
      .then(res => res.json())
      .then(res => setDetail(res));
  };

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h2>Pelanggan</h2>

      {/* Form Input */}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', marginBottom: '15px' }}>
        <input value={nama} onChange={e => setNama(e.target.value)} placeholder="Nama" required style={inputStyle} />
        <input value={alamat} onChange={e => setAlamat(e.target.value)} placeholder="Alamat" required style={inputStyle} />
        <select value={jenisKelamin} onChange={e => setJenisKelamin(e.target.value)} required style={inputStyle}>
          <option value="">Pilih Jenis Kelamin</option>
          <option value="Laki-laki">Laki-laki</option>
          <option value="Perempuan">Perempuan</option>
        </select>
        <input value={tempatLahir} onChange={e => setTempatLahir(e.target.value)} placeholder="Tempat Lahir" style={inputStyle} />
        <input value={tanggalLahir} onChange={e => setTanggalLahir(e.target.value)} type="date" style={inputStyle} />
        <button type="submit">{id ? 'Update' : 'Tambah'}</button>
      </form>

      {/* Tabel */}
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f0f0f0' }}>
            <th style={cellHeader}>ID</th>
            <th style={cellHeader}>Nama</th>
            <th style={cellHeader}>Alamat</th>
            <th style={cellHeader}>JK</th>
            <th style={cellHeader}>TTL</th>
            <th style={cellHeader}>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id}>
              <td style={cellBody}>{item.id}</td>
              <td style={{ ...cellBody, cursor: 'pointer' }} onClick={() => handleShowDetail(item.id)}>{item.nama}</td>
              <td style={cellBody}>{item.alamat}</td>
              <td style={cellBody}>{item.jenis_kelamin}</td>
              <td style={cellBody}>{item.tempat_lahir}, {item.tanggal_lahir}</td>
              <td style={cellBody}>
                <button onClick={() => handleEdit(item)} style={{ marginRight: 5 }}>Edit</button>
                <button onClick={() => handleDelete(item.id)}>Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Box Detail */}
      {detail && (
        <div style={{
          marginTop: 20,
          padding: 10,
          border: '1px solid #ccc',
          borderRadius: 4,
          background: '#f9f9f9'
        }}>
          <h4>Detail Pelanggan</h4>
          <p><strong>Nama:</strong> {detail.nama}</p>
          <p><strong>Alamat:</strong> {detail.alamat}</p>
          <p><strong>Jenis Kelamin:</strong> {detail.jenis_kelamin}</p>
          <p><strong>Tempat, Tanggal Lahir:</strong> {detail.tempat_lahir}, {detail.tanggal_lahir}</p>
          <button
            onClick={() => setDetail(null)}
            style={{
              marginTop: 10,
              padding: '5px 12px',
              border: '1px solid #ccc',
              backgroundColor: '#eee',
              cursor: 'pointer'
            }}
          >
            Tutup
          </button>
        </div>
      )}
    </div>
  );
}

// Styles
const inputStyle = {
  padding: '6px 10px',
  border: '1px solid #ccc',
  borderRadius: 4,
  fontSize: 14,
  width: '150px'
};

const cellHeader = {
  padding: '8px',
  border: '1px solid #ccc',
  textAlign: 'left',
  fontWeight: 'bold'
};

const cellBody = {
  padding: '8px',
  border: '1px solid #ccc',
  textAlign: 'left'
};

export default Pelanggan;
