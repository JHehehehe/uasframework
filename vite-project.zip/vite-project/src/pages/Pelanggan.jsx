import { useEffect, useState } from 'react';

function Pelanggan() {
  // State untuk menyimpan daftar data pelanggan
  const [data, setData] = useState([]);

  // State untuk menyimpan input nama dan alamat
  const [nama, setNama] = useState('');
  const [alamat, setAlamat] = useState('');

  // State untuk menyimpan id saat edit data
  const [id, setId] = useState(null);

  // State untuk menyimpan detail pelanggan yang dipilih
  const [detail, setDetail] = useState(null);

  // Fungsi untuk mengambil data pelanggan dari API
  const loadData = () => {
    fetch('http://localhost/api/pelanggan.php?action=read')
      .then(res => res.json())
      .then(res => setData(res)); // Simpan data ke state
  };

  // useEffect dijalankan sekali saat komponen dimuat
  useEffect(() => {
    loadData();
  }, []);

  // Fungsi untuk mengirim form (tambah atau update data)
  const handleSubmit = (e) => {
    e.preventDefault(); // Mencegah reload halaman
    const action = id ? 'update' : 'create'; // Tentukan aksi
    const payload = id ? { id, nama, alamat } : { nama, alamat };

    fetch(`http://localhost/api/pelanggan.php?action=${action}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(() => {
      // Reset form setelah submit
      setId(null);
      setNama('');
      setAlamat('');
      setDetail(null);
      loadData(); // Refresh data
    });
  };

  // Fungsi untuk mengisi form saat tombol Edit ditekan
  const handleEdit = (item) => {
    setId(item.id);
    setNama(item.nama);
    setAlamat(item.alamat);
  };

  // Fungsi untuk menghapus data pelanggan berdasarkan ID
  const handleDelete = (id) => {
    if (!window.confirm("Yakin ingin menghapus data ini?")) return;
    fetch('http://localhost/api/pelanggan.php?action=delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    }).then(() => loadData());
  };

  // Fungsi untuk menampilkan detail pelanggan
  const handleShowDetail = (id) => {
    fetch(`http://localhost/api/pelanggan.php?action=detail&id=${id}`)
      .then(res => res.json())
      .then(res => setDetail(res));
  };

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h2>Pelanggan</h2>

      {/* Form input data pelanggan */}
      <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '10px', marginBottom: '15px' }}>
        <input
          value={nama}
          onChange={e => setNama(e.target.value)}
          placeholder="Nama"
          required
          style={inputStyle}
        />
        <input
          value={alamat}
          onChange={e => setAlamat(e.target.value)}
          placeholder="Alamat"
          required
          style={inputStyle}
        />
        <button type="submit">{id ? 'Update' : 'Tambah'}</button>
      </form>

      {/* Tabel daftar pelanggan */}
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f0f0f0' }}>
            <th style={cellHeader}>ID</th>
            <th style={cellHeader}>Nama</th>
            <th style={cellHeader}>Alamat</th>
            <th style={cellHeader}>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id}>
              <td style={cellBody}>{item.id}</td>

              {/* Klik nama untuk menampilkan detail */}
              <td
                style={{ ...cellBody, cursor: 'pointer' }}
                onClick={() => handleShowDetail(item.id)}
              >
                {item.nama}
              </td>
              <td style={cellBody}>{item.alamat}</td>

              {/* Tombol Edit dan Hapus */}
              <td style={cellBody}>
                <button onClick={() => handleEdit(item)} style={{ marginRight: 5 }}>Edit</button>
                <button onClick={() => handleDelete(item.id)}>Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Box detail pelanggan */}
      {detail && (
        <div style={{
          marginTop: 20,
          padding: 10,
          border: '1px solid #ccc',
          borderRadius: 4,
          background: '#f9f9f9'
        }}>
          <h4>Detail Pelanggan</h4>
          <p><strong>Nama:</strong> {detail.nama}</p>
          <p><strong>Alamat:</strong> {detail.alamat}</p>
          <button
            onClick={() => setDetail(null)}
            style={{
              marginTop: 10,
              padding: '5px 12px',
              border: '1px solid #ccc',
              backgroundColor: '#eee',
              cursor: 'pointer'
            }}
          >
            Tutup
          </button>
        </div>
      )}
    </div>
  );
}

// Style untuk input dan tampilan tabel
const inputStyle = {
  padding: '6px 10px',
  border: '1px solid #ccc',
  borderRadius: 4,
  fontSize: 14,
  width: '150px'
};

const cellHeader = {
  padding: '8px',
  border: '1px solid #ccc',
  textAlign: 'left',
  fontWeight: 'bold'
};

const cellBody = {
  padding: '8px',
  border: '1px solid #ccc',
  textAlign: 'left'
};

export default Pelanggan;
