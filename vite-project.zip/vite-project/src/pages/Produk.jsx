import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

function Produk() {
  // State untuk menyimpan daftar produk dari database
  const [data, setData] = useState([]);

  // State untuk menyimpan nilai input form
  const [nama, setNama] = useState('');
  const [stok, setStok] = useState('');
  const [nominal, setNominal] = useState('');
  const [deskripsi, setDeskripsi] = useState('');

  // State untuk menyimpan ID produk yang sedang diedit (null = mode tambah)
  const [id, setId] = useState(null);

  // State untuk menyimpan data detail dari produk yang diklik
  const [detail, setDetail] = useState(null);

  // Hook dari react-router-dom untuk mendeteksi perubahan path (halaman)
  const location = useLocation();

  // Fungsi untuk mengambil data produk dari backend (API)
  const loadData = () => {
    fetch('http://localhost/api/produk.php?action=read') // Ambil data dari PHP
      .then(res => res.json())
      .then(res => setData(res)); // Simpan ke state
  };

  // useEffect akan dipanggil ketika komponen dimuat atau path berubah
  useEffect(() => {
    loadData();
  }, [location.pathname]);

  // Fungsi untuk handle submit form (tambah atau update produk)
  const handleSubmit = (e) => {
    e.preventDefault(); // Cegah reload halaman

    const action = id ? 'update' : 'create'; // Tentukan aksi berdasarkan apakah sedang edit
    const payload = id
      ? { id, nama, stok, nominal, deskripsi }
      : { nama, stok, nominal, deskripsi };

    // Kirim data ke server (API)
    fetch(`http://localhost/api/produk.php?action=${action}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(res => res.json())
      .then(res => {
        if (res.error) {
          alert('Gagal: ' + res.error);
          return;
        }

        // Reset form dan refresh data setelah berhasil
        setId(null);
        setNama('');
        setStok('');
        setNominal('');
        setDeskripsi('');
        setDetail(null);
        loadData();
      });
  };

  // Fungsi untuk mengisi form dengan data produk yang akan diedit
  const handleEdit = (item) => {
    setId(item.id);
    setNama(item.nama);
    setStok(item.stok);
    setNominal(item.nominal);
    setDeskripsi(item.deskripsi || ''); // Deskripsi bisa kosong
  };

  // Fungsi untuk menghapus produk berdasarkan ID
  const handleDelete = (id) => {
    if (!window.confirm("Yakin ingin menghapus produk ini?")) return;
    fetch('http://localhost/api/produk.php?action=delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    }).then(() => loadData()); // Refresh data setelah hapus
  };

  // Fungsi untuk menampilkan detail produk berdasarkan ID
  const handleShowDetail = (id) => {
    fetch(`http://localhost/api/produk.php?action=detail&id=${id}`)
      .then(res => res.json())
      .then(res => setDetail(res)); // Simpan detail ke state
  };

  return (
    <div style={{ maxWidth: 900, margin: '20px auto', fontFamily: 'sans-serif' }}>
      <h2>Produk</h2>

      {/* Form Tambah / Edit Produk */}
      <form
        onSubmit={handleSubmit}
        style={{
          display: 'flex',
          gap: '10px',
          marginBottom: '15px',
          alignItems: 'flex-start',
          flexWrap: 'wrap'
        }}
      >
        <input
          value={nama}
          onChange={e => setNama(e.target.value)}
          placeholder="Nama"
          required
          style={inputStyle}
        />

        <input
          value={stok}
          onChange={e => setStok(e.target.value)}
          placeholder="Stok"
          required
          style={inputStyle}
        />

        <input
          type="number"
          value={nominal}
          onChange={e => setNominal(e.target.value)}
          placeholder="Nominal"
          required
          style={inputStyle}
        />

        <textarea
          value={deskripsi}
          onChange={e => setDeskripsi(e.target.value)}
          placeholder="Deskripsi"
          rows={1}
          style={{ ...inputStyle, resize: 'none', height: '32px' }}
        />

        <button type="submit" style={{ padding: '5px 12px', height: '34px' }}>
          {id ? 'Update' : 'Tambah'}
        </button>
      </form>

      {/* Tabel Daftar Produk */}
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f5f5f5' }}>
            <th style={cellHeader}>ID</th>
            <th style={cellHeader}>Nama</th>
            <th style={cellHeader}>Stok</th>
            <th style={cellHeader}>Nominal</th>
            <th style={cellHeader}>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id}>
              <td style={cellBody}>{item.id}</td>

              {/* Klik nama untuk melihat detail */}
              <td onClick={() => handleShowDetail(item.id)}>{item.nama}</td>

              <td style={cellBody}>{item.stok}</td>
              <td style={cellBody}>{item.nominal}</td>
              <td style={cellBody}>
                <button onClick={() => handleEdit(item)} style={{ marginRight: 5 }}>Edit</button>
                <button onClick={() => handleDelete(item.id)}>Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Box Detail Produk */}
      {detail && (
        <div style={{
          marginTop: 20,
          border: '1px solid #ccc',
          padding: 10,
          background: '#f9f9f9',
          borderRadius: 4
        }}>
          <h4>Detail Produk</h4>
          <p><strong>Nama:</strong> {detail.nama}</p>
          <p><strong>Deskripsi:</strong> {detail.deskripsi}</p>
          <button
            onClick={() => setDetail(null)} // Tombol untuk menutup detail
            style={{
              marginTop: 10,
              padding: '5px 12px',
              border: '1px solid #ccc',
              backgroundColor: '#eee',
              cursor: 'pointer'
            }}
          >
            Tutup
          </button>
        </div>
      )}
    </div>
  );
}

// Style untuk input form
const inputStyle = {
  padding: '6px 10px',
  border: '1px solid #ccc',
  borderRadius: 4,
  width: '140px',
  fontSize: 14
};

// Style untuk header tabel
const cellHeader = {
  padding: '8px',
  border: '1px solid #ccc',
  fontWeight: 'bold',
  textAlign: 'left'
};

// Style untuk isi tabel
const cellBody = {
  padding: '8px',
  border: '1px solid #ccc',
  textAlign: 'left'
};

export default Produk;
