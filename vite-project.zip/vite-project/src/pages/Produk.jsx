import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

function Produk() {
  const [data, setData] = useState([]);
  const [kategoriList, setKategoriList] = useState([]);
  const [kategoriId, setKategoriId] = useState('');
  const [nama, setNama] = useState('');
  const [stok, setStok] = useState('');
  const [nominal, setNominal] = useState('');
  const [deskripsi, setDeskripsi] = useState('');
  const [gambar, setGambar] = useState(null);
  const [id, setId] = useState(null);
  const [detail, setDetail] = useState(null);
  const location = useLocation();

  const loadData = () => {
    fetch('http://localhost/api/produk.php?action=read')
      .then(res => res.json())
      .then(setData);
  };

  const loadKategori = () => {
    fetch('http://localhost/api/kategori.php?action=read')
      .then(res => res.json())
      .then(setKategoriList);
  };

  useEffect(() => {
    loadData();
    loadKategori();
  }, [location.pathname]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    if (id) formData.append('id', id);
    formData.append('nama', nama);
    formData.append('stok', stok);
    formData.append('nominal', nominal);
    formData.append('deskripsi', deskripsi);
    formData.append('kategori_id', kategoriId);
    if (gambar) formData.append('gambar', gambar);

    try {
      const res = await fetch(`http://localhost/api/produk.php?action=${id ? 'update' : 'create'}`, {
        method: 'POST',
        body: formData
      });

      const result = await res.json();

      if (result.error) {
        alert('Gagal: ' + result.error);
        return;
      }

      setId(null);
      setNama('');
      setStok('');
      setNominal('');
      setDeskripsi('');
      setGambar(null);
      setKategoriId('');
      setDetail(null);
      loadData();
    } catch (error) {
      alert('Terjadi kesalahan saat mengirim data!');
      console.error(error);
    }
  };

  const handleEdit = (item) => {
    setId(item.id);
    setNama(item.nama);
    setStok(item.stok);
    setNominal(item.nominal);
    setDeskripsi(item.deskripsi || '');
    setKategoriId(item.kategori_id || '');
    setGambar(null);
  };

  const handleDelete = (id) => {
    if (!window.confirm("Yakin ingin menghapus produk ini?")) return;
    fetch('http://localhost/api/produk.php?action=delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    }).then(() => loadData());
  };

  const handleShowDetail = (id) => {
    fetch(`http://localhost/api/produk.php?action=detail&id=${id}`)
      .then(res => res.json())
      .then(setDetail);
  };

  return (
    <div style={{ maxWidth: 900, margin: '20px auto', fontFamily: 'sans-serif' }}>
      <h2>Produk</h2>

      <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '10px', marginBottom: '15px', alignItems: 'flex-start', flexWrap: 'wrap' }}>
        <input value={nama} onChange={e => setNama(e.target.value)} placeholder="Nama" required style={inputStyle} />
        <input value={stok} onChange={e => setStok(e.target.value)} placeholder="Stok" required style={inputStyle} />
        <input type="number" value={nominal} onChange={e => setNominal(e.target.value)} placeholder="Nominal" required style={inputStyle} />
        <textarea value={deskripsi} onChange={e => setDeskripsi(e.target.value)} placeholder="Deskripsi" rows={1} style={{ ...inputStyle, resize: 'none', height: '32px' }} />

        <select value={kategoriId} onChange={e => setKategoriId(e.target.value)} required style={inputStyle}>
          <option value="">Pilih Kategori</option>
          {kategoriList.map(kat => (
            <option key={kat.id} value={kat.id}>{kat.nama}</option>
          ))}
        </select>

        <input type="file" accept="image/*" onChange={e => setGambar(e.target.files[0])} style={{ ...inputStyle, width: '200px' }} />
        <button type="submit" style={{ padding: '5px 12px', height: '34px' }}>{id ? 'Update' : 'Tambah'}</button>
      </form>

      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f5f5f5' }}>
            <th style={cellHeader}>ID</th>
            <th style={cellHeader}>Nama</th>
            <th style={cellHeader}>Stok</th>
            <th style={cellHeader}>Nominal</th>
            <th style={cellHeader}>Kategori</th>
            <th style={cellHeader}>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id}>
              <td style={cellBody}>{item.id}</td>
              <td onClick={() => handleShowDetail(item.id)}>{item.nama}</td>
              <td onClick={() => handleShowDetail(item.id)} style={cellBody}>{item.stok}</td>
              <td style={cellBody}>{item.nominal}</td>
              <td style={cellBody}>{item.kategori_nama || '-'}</td>
              <td style={cellBody}>
                <button onClick={() => handleEdit(item)} style={{ marginRight: 5 }}>Edit</button>
                <button onClick={() => handleDelete(item.id)}>Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

     {detail && (
  <div style={{ marginTop: 20, border: '1px solid #ccc', padding: 10, background: '#f9f9f9', borderRadius: 4, display: 'flex', gap: 20 }}>
   {detail.gambar ? (
  <img src={`http://localhost/uploads/${detail.gambar}`} alt={detail.nama} style={{ width: 150, height: 150, objectFit: 'cover', borderRadius: 4 }} />
) : (
  <p style={{ color: 'gray' }}>Gambar tidak tersedia</p>
)}

    <div>
      <h4>Detail Produk</h4>
      <p><strong>Nama:</strong> {detail.nama}</p>
      <p><strong>Deskripsi:</strong> {detail.deskripsi}</p>
      <p><strong>Stok:</strong> {detail.stok}</p>
      <p><strong>Nominal:</strong> Rp {Number(detail.nominal).toLocaleString('id-ID')}</p>
      <p><strong>Kategori:</strong> {detail.kategori_nama || '-'}</p>
      <button onClick={() => setDetail(null)} style={{ marginTop: 10, padding: '5px 12px', border: '1px solid #ccc', backgroundColor: '#eee', cursor: 'pointer' }}>Tutup</button>
    </div>
  </div>
)}

    </div>
  );
}

const inputStyle = {
  padding: '6px 10px',
  border: '1px solid #ccc',
  borderRadius: 4,
  width: '140px',
  fontSize: 14
};

const cellHeader = {
  padding: '8px',
  border: '1px solid #ccc',
  fontWeight: 'bold',
  textAlign: 'left'
};

const cellBody = {
  padding: '8px',
  border: '1px solid #ccc',
  textAlign: 'left'
};

export default Produk;
