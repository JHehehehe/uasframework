import { useEffect, useState } from 'react';

// Komponen utama
function Kategori() {
  // State untuk menyimpan data kategori dari server
  const [data, setData] = useState([]);

  // State untuk input form (nama dan deskripsi)
  const [nama, setNama] = useState('');
  const [deskripsi, setDeskripsi] = useState('');

  // State untuk menyimpan ID saat edit data
  const [id, setId] = useState(null);

  // State untuk menampilkan detail kategori
  const [detail, setDetail] = useState(null);

  // Fungsi untuk memuat data kategori dari server
  const loadData = () => {
    fetch('http://localhost/api/kategori.php?action=read')
      .then(res => res.json())
      .then(res => setData(res)); // Menyimpan data ke dalam state
  };

  // Memanggil loadData saat pertama kali komponen dirender
  useEffect(() => { loadData(); }, []);

  // Fungsi yang dijalankan saat form disubmit (tambah/update data)
  const handleSubmit = (e) => {
    e.preventDefault(); // Mencegah reload halaman

    // Tentukan aksi berdasarkan apakah sedang edit atau tambah
    const action = id ? 'update' : 'create';

    // Siapkan payload yang akan dikirim ke backend
    const payload = id
      ? { id, nama, deskripsi }
      : { nama, deskripsi };

    // Kirim data ke backend menggunakan fetch
    fetch(`http://localhost/api/kategori.php?action=${action}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(res => {
      if (res.error) {
        alert('Gagal: ' + res.error);
        return;
      }
      // Reset form dan reload data
      setId(null);
      setNama('');
      setDeskripsi('');
      setDetail(null);
      loadData();
    });
  };

  // Fungsi untuk mengisi form saat tombol Edit diklik
  const handleEdit = (item) => {
    setId(item.id);
    setNama(item.nama);
    setDeskripsi(item.deskripsi || '');
  };

  // Fungsi untuk menghapus data kategori
  const handleDelete = (id) => {
    if (!window.confirm("Yakin ingin menghapus kategori ini?")) return;

    fetch('http://localhost/api/kategori.php?action=delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    }).then(() => loadData());
  };

  // Fungsi untuk menampilkan detail dari suatu kategori
  const handleShowDetail = (id) => {
    fetch(`http://localhost/api/kategori.php?action=detail&id=${id}`)
      .then(res => res.json())
      .then(res => setDetail(res));
  };

  // Komponen UI yang ditampilkan
  return (
    <div style={{ maxWidth: 700, margin: '20px auto', fontFamily: 'sans-serif' }}>
      <h2>Kategori</h2>

      {/* Form input kategori */}
      <form onSubmit={handleSubmit} style={{
        display: 'flex',
        gap: '10px',
        marginBottom: '15px',
        alignItems: 'flex-start',
        flexWrap: 'wrap'
      }}>
        <input
          value={nama}
          onChange={e => setNama(e.target.value)}
          placeholder="Nama Kategori"
          required
          style={inputStyle}
        />
        <textarea
          value={deskripsi}
          onChange={e => setDeskripsi(e.target.value)}
          placeholder="Deskripsi"
          rows={1}
          style={{ ...inputStyle, resize: 'none', height: '32px' }}
        />
        <button type="submit" style={{ padding: '5px 12px', height: '34px' }}>
          {id ? 'Update' : 'Tambah'}
        </button>
      </form>

      {/* Tabel daftar kategori */}
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f5f5f5' }}>
            <th style={cellHeader}>ID</th>
            <th style={cellHeader}>Nama</th>
            <th style={cellHeader}>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id}>
              <td style={cellBody}>{item.id}</td>
              <td
                style={{ ...cellBody, cursor: 'pointer' }}
                onClick={() => handleShowDetail(item.id)}
              >
                {item.nama}
              </td>
              <td style={cellBody}>
                <button onClick={() => handleEdit(item)} style={{ marginRight: 5 }}>Edit</button>
                <button onClick={() => handleDelete(item.id)}>Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Kotak detail kategori */}
      {detail && (
        <div style={{
          marginTop: 20,
          border: '1px solid #ccc',
          padding: 10,
          background: '#f9f9f9',
          borderRadius: 4
        }}>
          <h4>Detail Kategori</h4>
          <p><strong>Nama:</strong> {detail.nama}</p>
          <p><strong>Deskripsi:</strong> {detail.deskripsi}</p>
          <button
            onClick={() => setDetail(null)}
            style={{
              marginTop: 10,
              padding: '5px 12px',
              border: '1px solid #ccc',
              backgroundColor: '#eee',
              cursor: 'pointer'
            }}
          >
            Tutup
          </button>
        </div>
      )}
    </div>
  );
}

// Style untuk input dan tabel
const inputStyle = {
  padding: '6px 10px',
  border: '1px solid #ccc',
  borderRadius: 4,
  width: '180px',
  fontSize: 14
};

const cellHeader = {
  padding: '8px',
  border: '1px solid #ccc',
  fontWeight: 'bold',
  textAlign: 'left'
};

const cellBody = {
  padding: '8px',
  border: '1px solid #ccc',
  textAlign: 'left'
};

export default Kategori;
