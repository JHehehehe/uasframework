function Home() {
  return (
    <div>
      <h1>Selamat Datang di Dashboard</h1>
      <p>Silakan pilih menu di atas untuk mengelola data produk, supplier, kategori, atau pelanggan.</p>
    </div>
  );
}

export default Home;
