import { useEffect, useState } from 'react';

function Supplier() {
  // State untuk menyimpan data supplier dari server
  const [data, setData] = useState([]);

  // State untuk input form
  const [nama, setNama] = useState('');
  const [kontak, setKontak] = useState('');

  // State untuk ID saat melakukan update
  const [id, setId] = useState(null);

  // State untuk menampilkan detail supplier
  const [detail, setDetail] = useState(null);

  // Fungsi untuk memuat data supplier dari backend
const loadData = () => {
  fetch('http://localhost/api/supplier.php?action=read')
    .then(res => res.json())
    .then(res => {
      const sorted = res.sort((a, b) => a.id - b.id); // Urut ID terkecil ke atas
      setData(sorted);
    });
};


  // useEffect akan menjalankan loadData sekali saat komponen pertama kali ditampilkan
  useEffect(() => {
    loadData();
  }, []);

  // Fungsi untuk handle submit form (tambah atau update supplier)
  const handleSubmit = (e) => {
    e.preventDefault();
    const action = id ? 'update' : 'create';
    const payload = id ? { id, nama, kontak } : { nama, kontak };

    fetch(`http://localhost/api/supplier.php?action=${action}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(() => {
      // Reset form setelah submit
      setId(null);
      setNama('');
      setKontak('');
      setDetail(null);
      loadData(); // Refresh data
    });
  };

  // Fungsi untuk mengisi form saat tombol edit ditekan
  const handleEdit = (item) => {
    setId(item.id);
    setNama(item.nama);
    setKontak(item.kontak);
  };

  // Fungsi untuk menghapus supplier
  const handleDelete = (id) => {
    if (!window.confirm("Yakin ingin menghapus supplier ini?")) return;
    fetch('http://localhost/api/supplier.php?action=delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    }).then(() => loadData());
  };

  // Fungsi untuk menampilkan detail supplier di bawah tabel
  const handleShowDetail = (id) => {
    fetch(`http://localhost/api/supplier.php?action=detail&id=${id}`)
      .then(res => res.json())
      .then(res => setDetail(res));
  };

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h2>Supplier</h2>

      {/* Form Tambah / Edit Supplier */}
      <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '10px', marginBottom: '15px' }}>
        <input
          value={nama}
          onChange={e => setNama(e.target.value)}
          placeholder="Nama"
          required
          style={inputStyle}
        />
        <input
          value={kontak}
          onChange={e => setKontak(e.target.value)}
          placeholder="Kontak"
          required
          style={inputStyle}
        />
        <button type="submit">{id ? 'Update' : 'Tambah'}</button>
      </form>

      {/* Tabel Daftar Supplier */}
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f0f0f0' }}>
            <th style={cellHeader}>ID</th>
            <th style={cellHeader}>Nama</th>
            <th style={cellHeader}>Kontak</th>
            <th style={cellHeader}>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id}>
              <td style={cellBody}>{item.id}</td>
              <td
                style={{ ...cellBody, cursor: 'pointer' }}
                onClick={() => handleShowDetail(item.id)} // Tampilkan detail saat nama diklik
              >
                {item.nama}
              </td>
              <td style={cellBody}>{item.kontak}</td>
              <td style={cellBody}>
                <button onClick={() => handleEdit(item)} style={{ marginRight: 5 }}>Edit</button>
                <button onClick={() => handleDelete(item.id)}>Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Box Detail Supplier */}
      {detail && (
        <div style={{
          marginTop: 20,
          border: '1px solid #ccc',
          padding: 10,
          borderRadius: 4,
          backgroundColor: '#f9f9f9'
        }}>
          <h4>Detail Supplier</h4>
          <p><strong>Nama:</strong> {detail.nama}</p>
          <p><strong>Kontak:</strong> {detail.kontak}</p>
          <button
            onClick={() => setDetail(null)}
            style={{
              marginTop: 10,
              padding: '5px 12px',
              backgroundColor: '#eee',
              border: '1px solid #ccc',
              cursor: 'pointer'
            }}
          >
            Tutup
          </button>
        </div>
      )}
    </div>
  );
}

// Style input dan tabel
const inputStyle = {
  padding: '6px 10px',
  border: '1px solid #ccc',
  borderRadius: 4,
  fontSize: 14,
  width: '150px'
};

const cellHeader = {
  padding: '8px',
  border: '1px solid #ccc',
  fontWeight: 'bold',
  textAlign: 'left'
};

const cellBody = {
  padding: '8px',
  border: '1px solid #ccc',
  textAlign: 'left'
};

export default Supplier;
